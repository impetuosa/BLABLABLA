# Please ensure that folder are properly set.

PHARO=./pharo
MODEL_BASE=../moxingmodels
ONTOLOGY_BASE=../ontologies
LOG_BASE=logs/

MODEL_ARGOUML=$MODEL_BASE/java.moxing.argouml.ston
ONTOLOGY_ARGOUML=$ONTOLOGY_BASE/java.ontology.argouml.ston

MODEL_PETSTORE=$MODEL_BASE/java.moxing.petstore.ston
ONTOLOGY_PETSTORE=$ONTOLOGY_BASE/java.ontology.petstore.ston

MODEL_CALYPSO=$MODEL_BASE/pharo.moxing.calypso.ston
ONTOLOGY_CALYPSO=$ONTOLOGY_BASE/pharo.ontology.calypso.ston

MODEL_MOOSE=$MODEL_BASE/pharo.moxing.moose.ston
ONTOLOGY_MOOSE=$ONTOLOGY_BASE/pharo.ontology.moose.ston

MODEL_EPAIE=$MODEL_BASE/access.moxing.epaie.ston
ONTOLOGY_EPAIE=$ONTOLOGY_BASE/access.ontology.epaie.ston

MODEL_EGRC=$MODEL_BASE/access.moxing.egrc.ston
ONTOLOGY_EGRC=$ONTOLOGY_BASE/access.ontology.egrc.ston

MODEL_NORTHWIND=$MODEL_BASE/access.moxing.northwind.ston
ONTOLOGY_NORTHWIND=$ONTOLOGY_BASE/access.ontology.northwind.ston




# Calypso - Northwind
MODEL=$MODEL_CALYPSO
ONTOLOGY=$ONTOLOGY_NORTHWIND
LOG=$LOG_BASE/calypso-northwind.txt
if test ! -f "$LOG"; then
	echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
fi 
# Calypso - EPAIE
MODEL=$MODEL_CALYPSO
ONTOLOGY=$ONTOLOGY_EPAIE
LOG=$LOG_BASE/calypso-epaie.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 



# Calypso - PETSTORE 
MODEL=$MODEL_CALYPSO
ONTOLOGY=$ONTOLOGY_PETSTORE
LOG=$LOG_BASE/calypso-petstore.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 

# Calypso - ARGOUML
MODEL=$MODEL_CALYPSO
ONTOLOGY=$ONTOLOGY_ARGOUML
LOG=$LOG_BASE/calypso-argo.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 

# MOOSE - PETSTORE
MODEL=$MODEL_MOOSE
ONTOLOGY=$ONTOLOGY_PETSTORE
LOG=$LOG_BASE/moose-petstore.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 




# MOOSE - EPAIE
MODEL=$MODEL_MOOSE
ONTOLOGY=$ONTOLOGY_EPAIE
LOG=$LOG_BASE/moose-epaie.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi

# NORTHWIND - CALYPSO
MODEL=$MODEL_NORTHWIND
ONTOLOGY=$ONTOLOGY_CALYPSO
LOG=$LOG_BASE/northwind-calypso.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 


# NORTHWIND - PETSTORE
MODEL=$MODEL_NORTHWIND
ONTOLOGY=$ONTOLOGY_PETSTORE
LOG=$LOG_BASE/northwind-petstore.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 



# EPAIE - PETSTORE . 
# EPAIE IS NOT SHIPPED 
# MODEL=$MODEL_EPAIE
# ONTOLOGY=$ONTOLOGY_PETSTORE
# LOG=$LOG_BASE/epaie-pet.txt
#if test ! -f "$LOG"; then
#		echo $LINENO
#	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
	
# fi 



# EPAIE - CALYPSO 
# EPAIE IS NOT SHIPPED 
# MODEL=$MODEL_EPAIE
# ONTOLOGY=$ONTOLOGY_CALYPSO
#LOG=$LOG_BASE/epaie-calypso.txt
# if test ! -f "$LOG"; then
#		echo $LINENO
#	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
#fi 



# EPAIE - MOOSE 
# MODEL=$MODEL_EPAIE
# ONTOLOGY=$ONTOLOGY_MOOSE
# LOG=$LOG_BASE/epaie-moose.txt
#if test ! -f "$LOG"; then
#		echo $LINENO
#	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
#fi 


# EPAIE - ArgoUML 
#MODEL=$MODEL_EPAIE
#ONTOLOGY=$ONTOLOGY_ARGOUML
#LOG=$LOG_BASE/epaie-argo.txt
#if test ! -f "$LOG"; then
#		echo $LINENO
#	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
#fi 


# PETSTORE - EPAIE
MODEL=$MODEL_PETSTORE
ONTOLOGY=$ONTOLOGY_EPAIE
LOG=$LOG_BASE/petstore-epaie.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi



# PETSTORE - NORTHWIND
MODEL=$MODEL_PETSTORE
ONTOLOGY=$ONTOLOGY_NORTHWIND
LOG=$LOG_BASE/petstore-northwind.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi

# PETSTORE - MOOSE
MODEL=$MODEL_PETSTORE
ONTOLOGY=$ONTOLOGY_MOOSE
LOG=$LOG_BASE/petstore-moose.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi


# PETSTORE - CALYPSO
MODEL=$MODEL_PETSTORE
ONTOLOGY=$ONTOLOGY_CALYPSO
LOG=$LOG_BASE/petstore-calypso.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi



# ArgoUML - EPAIE
MODEL=$MODEL_ARGOUML
ONTOLOGY=$ONTOLOGY_EPAIE
LOG=$LOG_BASE/argo-epaie.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi



# ArgoUML - CALYPSO
MODEL=$MODEL_ARGOUML
ONTOLOGY=$ONTOLOGY_CALYPSO
LOG=$LOG_BASE/argo-calypso.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi




# ArgoUML - ArgoUML
MODEL=$MODEL_ARGOUML
ONTOLOGY=$ONTOLOGY_ARGOUML
LOG=$LOG_BASE/argo-argo.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi

# PetStore - PetStore
MODEL=$MODEL_PETSTORE
ONTOLOGY=$ONTOLOGY_PETSTORE
LOG=$LOG_BASE/petstore-petstore.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
fi 


# ArgoUML - PetStore - 
MODEL=$MODEL_ARGOUML
ONTOLOGY=$ONTOLOGY_PETSTORE
LOG=$LOG_BASE/argo-petstore.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 


# PetStore - ArgoUML
MODEL=$MODEL_PETSTORE
ONTOLOGY=$ONTOLOGY_ARGOUML
LOG=$LOG_BASE/petstore-argo.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 

# Calypso - Calypso
MODEL=$MODEL_CALYPSO
ONTOLOGY=$ONTOLOGY_CALYPSO
LOG=$LOG_BASE/calypso-calypso.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 

# MOOSE - MOOSE
MODEL=$MODEL_MOOSE
ONTOLOGY=$ONTOLOGY_MOOSE
LOG=$LOG_BASE/moose-moose.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 


# Calypso - MOOSE
MODEL=$MODEL_CALYPSO
ONTOLOGY=$ONTOLOGY_MOOSE
LOG=$LOG_BASE/calypso-moose.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 

# MOOSE - Calypso
MODEL=$MODEL_MOOSE
ONTOLOGY=$ONTOLOGY_CALYPSO
LOG=$LOG_BASE/moose-calypso.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 

# NORTHWIND - NORTHWIND
MODEL=$MODEL_NORTHWIND
ONTOLOGY=$ONTOLOGY_NORTHWIND
LOG=$LOG_BASE/northwind-northwind.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 


# NORTHWIND - EPAIE
MODEL=$MODEL_NORTHWIND
ONTOLOGY=$ONTOLOGY_EPAIE
LOG=$LOG_BASE/northwind-epaie.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 


# EPAIE - EPAIE - 
#MODEL=$MODEL_EPAIE
#ONTOLOGY=$ONTOLOGY_EPAIE
#LOG=$LOG_BASE/epaie-epaie.txt
#if test ! -f "$LOG"; then
#		echo $LINENO
#	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
#fi 


# EPAIE - NORTHWIND 
#MODEL=$MODEL_EPAIE
#ONTOLOGY=$ONTOLOGY_NORTHWIND
#LOG=$LOG_BASE/epaie-northwind.txt
#if test ! -f "$LOG"; then
#		echo $LINENO
#	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
#fi 



# ARGOUML - NORTHWIND

MODEL=$MODEL_ARGOUML
ONTOLOGY=$ONTOLOGY_NORTHWIND
LOG=$LOG_BASE/argo-northwind.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 


# ARGOUML - MOOSE 

MODEL=$MODEL_ARGOUML
ONTOLOGY=$ONTOLOGY_MOOSE
LOG=$LOG_BASE/argo-moose.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 

# MOOSE - ARGOUML

MODEL=$MODEL_MOOSE
ONTOLOGY=$ONTOLOGY_ARGOUML
LOG=$LOG_BASE/moose-argo.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 




# NORTHWIND - ARGOUML - 

MODEL=$MODEL_NORTHWIND
ONTOLOGY=$ONTOLOGY_ARGOUML
LOG=$LOG_BASE/northwind-argo.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 


# MOOSE - NORTHWIND


MODEL=$MODEL_MOOSE
ONTOLOGY=$ONTOLOGY_NORTHWIND
LOG=$LOG_BASE/moose-northwind.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 



# NORTHWIND - MOOSE 

MODEL=$MODEL_NORTHWIND
ONTOLOGY=$ONTOLOGY_MOOSE
LOG=$LOG_BASE/northwind-moose.txt
if test ! -f "$LOG"; then
		echo $LINENO
	./$PHARO Pharo.image eval "SPCompareExperiment compare: '$MODEL' with: '$ONTOLOGY' logging:'$LOG'"
 
	
fi 



# Full aggregation 

./$PHARO Pharo.image eval "SPCompareLogs process"



# Aggregate by transforming type. 

./$PHARO Pharo.image eval "SPCompareDistanceLogs process"
 
